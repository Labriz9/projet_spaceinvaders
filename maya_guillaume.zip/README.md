[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=9587214&assignment_repo_type=AssignmentRepo)

Binôme: Maya AL FARRA - Guillaume TRUONG

lien git : 
https://github.com/cpe-lyon/tp-5---groupe-a-al_farra-truong-dev

-TAD : on a utilisé des listes: 
- pour les aliens : une liste qui contient les différents aliens
- pour les protections
- pour les projectiles du joueur et des aliens : deux listes qui contiennent leurs id pour faciliter leur destruction lors d'une collision ou d'une sortie du canvas
- "remove_list_..." : listes d'objets à détruire après les boucles (pour ne pas modifier les listes avant la fin des boucles) dans lesquelles les objets à détruire sont stockés.


